#include "File.h"

bool File::ReadFromFile(std::string filename)
{
	return false;
}

bool File::WriteToFile(std::string filename)
{
	return false;
}

std::string File::ReadContentsFromFile(std::string filename)
{
	return std::string();
}
