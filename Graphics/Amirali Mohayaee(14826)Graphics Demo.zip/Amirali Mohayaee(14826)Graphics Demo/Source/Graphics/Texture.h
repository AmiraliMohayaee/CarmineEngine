#pragma once




class Texture
{
public:
	Texture();



private:



};